/**
 * Common/Permission.gs
 * Extracted from Services/AuthService.gs during the folder/SPA restructuring.
 * "Is this session's identity valid" (AuthService.gs: login/logout/
 * validateSession/password hashing) and "is this session allowed to do X"
 * (this file) are separate concerns - most *Service.gs files only ever need
 * PermissionService.checkSessionAndPermission, never anything else
 * AuthService.gs exposes, so it gets its own file under Common/ rather than
 * living under Services/ next to the single-purpose *Service.gs files.
 *
 * ES5 only.
 */

var PermissionService = (function () {

  /**
   * Server-side permission check (spec section 21: "Permissions must be
   * checked server-side"). permissionKey values are the ones seeded in
   * seed.sql's permissions table (e.g. 'jobcard.view', 'jobcard.edit',
   * 'fms.edit', 'inventory.edit', ...).
   */
  function hasPermission(userId, permissionKey, existingConn) {
    if (!userId || !isNonEmptyString_(permissionKey)) { return false; }
    var rows = DatabaseService.executeQuery(
      'SELECT COUNT(*) AS cnt FROM role_permissions rp ' +
      'JOIN users u ON u.role_id = rp.role_id ' +
      'JOIN permissions p ON p.permission_id = rp.permission_id ' +
      'WHERE u.user_id = ? AND p.permission_key = ? AND u.is_active = 1',
      [userId, permissionKey],
      existingConn
    );
    return rows.length > 0 && Number(rows[0].cnt) > 0;
  }

  /**
   * Combined session+permission check on ONE JDBC connection instead of two
   * separate ones - this was the single biggest source of the original
   * "loading is slow" report (every module page load fires several of
   * these). Every *Service.gs's checkAccess_() calls this instead of
   * calling AuthService.validateSession/hasPermission separately.
   *
   * permissionKey is optional - pass null/undefined to only check the
   * session (matches a plain "just validate the session" call site).
   *
   * Returns { user: {...}|null, allowed: boolean }. allowed is only
   * meaningful when user is non-null.
   */
  function checkSessionAndPermission(sessionId, permissionKey) {
    return DatabaseService.withReadConnection(function (conn) {
      var user = AuthService.validateSession(sessionId, conn);
      if (!user) { return { user: null, allowed: false }; }
      var allowed = permissionKey ? hasPermission(user.userId, permissionKey, conn) : true;
      return { user: user, allowed: allowed };
    });
  }

  return {
    hasPermission: hasPermission,
    checkSessionAndPermission: checkSessionAndPermission
  };
})();
