/**
 * Database/CacheLayer.gs
 * Server-side cache for the heaviest shared read-only aggregate queries,
 * backed by CacheService's script cache (CacheService.getScriptCache() -
 * shared across every user/session hitting this deployment, not per-user;
 * that is deliberate, since these are org-wide aggregates, not
 * user-specific data).
 *
 * TRADEOFF - spelled out rather than hidden: a cached value can be up to
 * ttlSeconds stale, and there is no write-side invalidation anywhere in
 * this project - a job card status change, a new FMS stage transaction,
 * a fresh inspection, etc. does NOT proactively clear anything cached
 * here. A cached value simply expires on its own after ttlSeconds and the
 * next call recomputes it. Because of that:
 *   - Keep ttlSeconds short (seconds, not minutes) on anything that could
 *     drive an operational decision.
 *   - Do NOT apply this to paginated/business list endpoints (job cards,
 *     purchase orders, bundles, ...) - a user needs to see their own
 *     just-made write reflected immediately there. This is only applied to
 *     the two heaviest shared dashboard aggregates (see DashboardService.gs:
 *     getOverviewKpis, getFmsStageSummary) where a ~20 second staleness
 *     window is an acceptable trade for far fewer JDBC round trips when many
 *     users have the dashboard open at once.
 *
 * ES5 only.
 */
var CacheLayer = (function () {
  var cache = CacheService.getScriptCache();

  /**
   * Returns the cached value for key if present and unexpired; otherwise
   * calls computeFn(), caches its result for ttlSeconds, and returns it.
   * computeFn's result must be JSON-serializable (it is stored as a JSON
   * string) and fit CacheService's ~100KB per-value limit - if it doesn't,
   * the cache write is skipped (logged, not thrown) and the freshly
   * computed value is still returned, so an oversized result never breaks
   * the caller, it just never gets cached.
   */
  function get(key, ttlSeconds, computeFn) {
    try {
      var cached = cache.get(key);
      if (cached !== null) {
        return JSON.parse(cached);
      }
    } catch (e) {
      Logger.log('CacheLayer.get: cache read failed for key ' + key + ': ' + e);
    }

    var value = computeFn();

    try {
      cache.put(key, JSON.stringify(value), ttlSeconds);
    } catch (e) {
      Logger.log('CacheLayer.get: cache write failed for key ' + key + ' (value may exceed the ~100KB per-key limit): ' + e);
    }

    return value;
  }

  function invalidate(key) {
    try { cache.remove(key); } catch (e) {}
  }

  return { get: get, invalidate: invalidate };
})();
