/**
 * Code.gs
 * Web app entry point for the SPA rewrite. doGet() ALWAYS serves the single
 * SPA shell (Frontend/index.html) - there is no more a ?page=... query
 * string that picks between separate doGet-served templates. Which view is
 * showing (login vs. dashboard vs. any module) is decided entirely
 * client-side, by Common/Components.html's Router, based on the session
 * stored in the browser (see Common/JS.html's getSession()/setSession()).
 *
 * Moving between modules is now a client-side DOM swap (Router.navigate),
 * not a new HTTP request to Apps Script - so it is instant, and it can no
 * longer hit the old "dead navigateToPage() + missing template.appUrl"
 * class of bug: there is no cross-page top-level navigation happening for
 * in-app module switching any more, only for the very first page load.
 *
 * KNOWN LIMITATION (by design, not an oversight): each page render lives
 * inside HtmlService's sandboxed googleusercontent.com iframe, and
 * cross-origin restrictions mean in-page JS cannot update the browser's own
 * address bar or history from inside that iframe. So there is intentionally
 * no deep-linking to a specific module and no back-button support between
 * modules - refreshing the browser (or opening the exec URL fresh) always
 * lands on whatever Router.init() decides by default (the login view, or
 * the dashboard if a valid session is already in the browser's storage),
 * never on whichever module you were last looking at.
 *
 * ES5 only.
 */

function doGet(e) {
  var template = HtmlService.createTemplateFromFile('Frontend/index');
  // The SPA shell needs its own deployed exec URL for things like the
  // "web-app URL is unavailable" guard inside the login view - see
  // Frontend/Views/Login.html.
  template.appUrl = ScriptApp.getService().getUrl();
  return template.evaluate()
    .setTitle('Garment Manufacturing ERP')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setFaviconUrl('https://www.google.com/images/icons/product/sheets-32.png')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * Used from Frontend/index.html as <?!= include('Common/CSS'); ?>,
 * <?!= include('Frontend/Views/Dashboard'); ?>, etc.
 *
 * IMPORTANT: filename must be the FULL folder-prefixed Apps Script file
 * name, using '/' as the separator - e.g. 'Common/CSS', 'Common/JS',
 * 'Frontend/Views/Dashboard'. This is because clasp turns every local
 * subfolder into a literal '/'-joined prefix on the underlying Apps Script
 * file's name (a local file at Frontend/Views/Dashboard.html becomes the
 * Apps Script file named "Frontend/Views/Dashboard", not "Dashboard") -
 * confirmed against clasp's own documentation before this restructuring was
 * done. Get this wrong and include() throws a "file not found" style error
 * at render time, not at push time.
 *
 * Returns raw file content - note this does NOT recursively evaluate
 * <?!= ?> scriptlet tags inside the included file (a well-known HtmlService
 * limitation), so Common/CSS.html, Common/JS.html, Common/Components.html
 * and every Frontend/Views/*.html file are plain static HTML/CSS/JS with no
 * server-side templating of their own; only Frontend/index.html itself is
 * evaluated as a template (it is the only file with <?= ?>/<?!= ?> that
 * need real scriptlet evaluation, via appUrl).
 */
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}
